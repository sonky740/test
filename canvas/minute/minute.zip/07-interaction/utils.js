const canUtil = {
	toRadian: function (degree) {
		return degree * Math.PI/180;
	}
};